#pragma once

#include "../../../../external/lodepng/lodepng.h"
