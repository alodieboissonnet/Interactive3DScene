#pragma once

#include <GLFW/glfw3.h>
