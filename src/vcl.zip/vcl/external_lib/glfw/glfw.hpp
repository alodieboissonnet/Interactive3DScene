#pragma once

#include "window/window.hpp"
#include "fps_counter/fps_counter.hpp"
