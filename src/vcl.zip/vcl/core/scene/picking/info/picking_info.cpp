#include "picking_info.hpp"

namespace vcl
{

picking_info::picking_info()
    :picking_valid(false), intersection({0,0,0}), normal({0,0,0})
{

}

}
