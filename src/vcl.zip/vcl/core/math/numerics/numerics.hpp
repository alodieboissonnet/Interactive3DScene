#pragma once

namespace vcl
{

bool is_equal(float a, float b);

}
