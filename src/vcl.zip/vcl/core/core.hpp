#pragma once

#include "helper/helper.hpp"
#include "math/math.hpp"
#include "opengl/opengl.hpp"
#include "scene/scene.hpp"
#include "shape/shape.hpp"
#include "drawable/drawable.hpp"
